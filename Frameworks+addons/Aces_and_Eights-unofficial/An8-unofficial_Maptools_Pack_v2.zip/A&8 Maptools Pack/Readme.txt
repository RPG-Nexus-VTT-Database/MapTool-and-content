A free font "faywood.ttf" was used in the A&8's book. 
I've used this font in my framework to make the chracter sheet feel more "official".
I've included it so you don't hvae to go looking online for the font.
On windows just right-click and hit install, or copy it to your fonts folder.

The Shot Clocks and Silos folder contains properly scaled silouttes and objects. Drag them into your background or object layer.

To use the excel converter:
Open thhe excel file.
Use the "edit links" feature in excel and point it at the file your character is in.
This will change all the formulas to point at that workbook.
Select a cell with data in it.
Select all (ctrl-A)
Copy (ctrl-C)
Impersonate Target Token.
Click ImportExcelPC, select A&8 FUll.
Paste into maptools chat (ctrl-V)
Press Enter
Open Character Sheet, should all skills and attributes.